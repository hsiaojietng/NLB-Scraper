import scrapy
import requests
from myLibrary.items import myLibraryItem
from datetime import datetime
import re
import urllib.parse
from requests import get
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException
import time
from scrapy.http import HtmlResponse
from scrapy import signals
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
#For writing in excel
import requests


class myLibrary(scrapy.Spider):                
        name = "my_scraper"
        page_number = 2
        start_urls = ["https://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/MSGTRN/WPAC/COMB"]
        current_url = ""
        clicked = True

        def __init__(self):
                self.driver = webdriver.Chrome()

        def parse(self, response):
                time.sleep(20)
                #Clicking on the first book
                if(clicked == True):
                        Firstbook = self.driver.find_element_by_xpath("//div[contains(@class, 'card card-grid')]//div//h5//a//span[1]")
                        Firstbook.click()
                        clicked = False

                #Check if nextbutton is clickable
                nextButton = self.driver.find_element_by_xpath("//ul[contains(@class, 'list-inline mb-0 d-flex justify-content-between')]//li//a)[3]")
                while(nextButton.click() == True):
                        time.sleep(30)
                        eachBook()
                        #Click on next button
                        nextButton.click()
                        

        def eachBook():
                #Click on 'Show more'
                show = self.driver.find_element_by_xpath("//a[contains(@id, 'loadMore')]")
                show.click()

                items = myLibraryItem()

                #Getting genre
                items['genre'] = response.xpath("(//div//div[contains(@class, 'col pl-sm-0')]//span[contains(@class, 'd-block')]//span)[3]/text()").extract()

                #Getting booktitle
                items['title'] = response.xpath("(//div//div[contains(@class, 'col pl-sm-0')]//span[contains(@class, 'd-block')]//span)[1]/text()").extract()
                

                #Getting isbn
                items['isbn'] = response.xpath("(//div//div[contains(@class, 'col pl-sm-0')]//span[contains(@class, 'd-block')])[8]/text()").extract()
                        
                #Getting author
                items['author'] = response.xpath("(//div//div[contains(@class, 'col pl-sm-0')]//span[contains(@class, 'd-block')])[2]//span/text()").extract()

                #Getting publisher
                items['publisher'] = response.xpath("(//div//div[contains(@class, 'col pl-sm-0')]//span[contains(@class, 'd-block')])[3]/text()").extract()
                
                #Getting brn
                items['brn'] = response.xpath("(//div//div[contains(@class, 'col pl-sm-0')]//span[contains(@class, 'd-block')])[16]/text()").extract()

                yield items

                #Writing data into file
                filename = "C:\\Users\\Ng Hsiao Jiet\\Desktop\\myLibrary\\myLibrary\\bookTitle.csv"
                fields = ["genre", "title", "isbn", "author", "publisher", "brn"]
                with open(filename, "w") as f:
                        f.write("{}\n".format('\t'.join(str(field)for field in fields))) #write the header

                        for item in items:
                                f.write("{}\n".format('\t'.join(str(item[field]) 
                                      for field in fields)))


                
                      

