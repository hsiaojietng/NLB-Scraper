﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_call
{
    class Book
    {
        private string BID;

        public string bid
        {
            get { return BID; }
            set { BID = value; }
        }

        private string ISBN;

        public string isbn
        {
            get { return ISBN; }
            set { ISBN = value; }
        }

        private string Title;

        public string title
        {
            get { return Title; }
            set { Title = value; }
        }

        private string Author;

        public string author
        {
            get { return Author; }
            set { Author = value; }
        }

        public Book() { }





    }
}
