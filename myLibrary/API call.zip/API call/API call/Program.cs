﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Diagnostics;
using System.Net;
using CsvHelper;
using System.IO;

namespace API_call
{
    
    class Program
    {
        List<Book> records = new List<Book> { };
        static void Main()
        {
            Program newProgram = new Program();
            newProgram.SearchBook();
            using (var writer = new StreamWriter("C:\\Users\\Ng Hsiao Jiet\\Desktop\\myLibrary\\myLibrary\\bookTitle.csv"))
            using (var csv = new CsvWriter(writer))
            {
                csv.WriteRecords(newProgram.records);
                csv.NextRecord();
            }

        }

        public void SearchBook()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            try
            {
                CatalogueService.CatalogueServiceClient client = new CatalogueService.CatalogueServiceClient();
                CatalogueService.SearchRequest sRequest = new CatalogueService.SearchRequest();
                CatalogueService.SearchItem newSearchItem = new CatalogueService.SearchItem();

                sRequest.APIKey = "RGV2LUNoaWVuWWVlbjpDWW5sYkAxMjMk";

                List<CatalogueService.SearchItem> searchItemList = new List<CatalogueService.SearchItem>();

                newSearchItem.SearchField = "Author"; //Language, BranchID, MediaCode
                newSearchItem.SearchTerms = "Anthony"; //English, PRPL, BK
                searchItemList.Add(newSearchItem);
                CatalogueService.Modifiers mod = new CatalogueService.Modifiers();
                mod.StartRecordPosition = 0;
                mod.MaximumRecords = 100;
                sRequest.SearchItems = searchItemList.ToArray();
                sRequest.Modifiers = mod;

                CatalogueService.SearchResponse res = client.Search(sRequest);

                if (res.Status == "OK")
                {
                    //process result list
                    Debug.WriteLine("This is supposed to show!");
                    int n = 1;
           
                    foreach (var t in res.Titles)
                    {
                        Book bookDetails = new Book();
                        bookDetails.bid = t.BID;
                        bookDetails.isbn = t.ISBN;
                        bookDetails.title = t.TitleName;
                        bookDetails.author = t.Author;
                        records.Add(bookDetails);
                        Debug.WriteLine(n.ToString() + ".)");
                        Debug.WriteLine("BID:" + t.BID);
                        Debug.WriteLine("ISBN:" + t.ISBN);
                        Debug.WriteLine("Title:" + t.TitleName);
                        Debug.WriteLine("Author:" + t.Author);
                        Debug.WriteLine("MediaCode:" + t.MediaCode);
                        n++;
                    }
                }
                else
                {
                    //exception handle
                    Debug.WriteLine(res.ErrorMessage);
                }

                client.Close();
            }
            catch(Exception ex)
            {
                Debug.WriteLine(ex);
            }
            
        }

    }
}
